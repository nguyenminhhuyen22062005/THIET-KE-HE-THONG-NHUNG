﻿#ifndef LCD_H_
#define LCD_H_

// SỬA LẠI THÀNH 8MHz ĐỂ DELAY CHÍNH XÁC
#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>
#include <math.h>

// ==== Cấu hình chân LCD (ĐÚNG THEO CÁCH MẮC THỰC TẾ) ====
// RS, RW, EN nối PORTA
#define LCD_RS_PORT PORTA
#define LCD_RS_DDR  DDRA
#define RS          PA2

#define LCD_RW_PORT PORTA
#define LCD_RW_DDR  DDRA
#define RW          PA1

#define LCD_EN_PORT PORTA
#define LCD_EN_DDR  DDRA
#define EN          PA0

// D4–D7: Hỗn hợp PORTB và PORTA
// D4 = PB5, D5 = PB4, D6 = PB3, D7 = PA3
#define D4_PORT     PORTB
#define D4_DDR      DDRB
#define D4_PIN      PB5

#define D5_PORT     PORTB
#define D5_DDR      DDRB
#define D5_PIN      PB4

#define D6_PORT     PORTB
#define D6_DDR      DDRB
#define D6_PIN      PB3

#define D7_PORT     PORTB
#define D7_DDR      DDRB
#define D7_PIN      PB2

void lcd_command(unsigned char cmnd);
void lcd_char(unsigned char data);
void lcd_init(void);
void lcd_gotoxy(unsigned char x, unsigned char y);
void lcd_string(const char *str);
void lcd_clear(void);
void lcd_print2(uint8_t v);
void lcd_float(float num, uint8_t digits);
void lcd_cursor_on(void);
void lcd_cursor_off(void);

#endif /* LCD_H_ */
