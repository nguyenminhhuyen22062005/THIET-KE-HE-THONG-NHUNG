main.d main.o: .././main.c \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\io.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\sfr_defs.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h \
 C:\Users\Admin\Desktop\7.0\Packs\atmel\ATmega_DFP\1.7.374\include/avr/iom16a.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\portpins.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\common.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\version.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\fuse.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\lock.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\util\delay.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\util\delay_basic.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\math.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdlib.h \
 c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h \
 .././lcd.h .././i2c.h .././ds1307.h .././hx711.h .././keypad.h \
 .././servobuzzer.h

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\io.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\sfr_defs.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\inttypes.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stdint.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdint.h:

C:\Users\Admin\Desktop\7.0\Packs\atmel\ATmega_DFP\1.7.374\include/avr/iom16a.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\portpins.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\common.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\version.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\fuse.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\avr\lock.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\util\delay.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\util\delay_basic.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\math.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\avr\include\stdlib.h:

c:\users\admin\desktop\7.0\toolchain\avr8\avr8-gnu-toolchain\lib\gcc\avr\5.4.0\include\stddef.h:

.././lcd.h:

.././i2c.h:

.././ds1307.h:

.././hx711.h:

.././keypad.h:

.././servobuzzer.h:
