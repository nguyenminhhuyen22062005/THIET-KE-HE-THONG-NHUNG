﻿#include "lcd.h"

// === HÀM NỘI BỘ (STATIC) ===

// Tạo xung Enable
static void lcd_enable_pulse(void) {
	LCD_EN_PORT |= (1 << EN);
	_delay_us(1);
	LCD_EN_PORT &= ~(1 << EN);
	_delay_us(45);  // Chờ LCD xử lý lệnh
}

// Gửi 4 bit (Nibble) - Hỗ trợ chân hỗn hợp
static void lcd_send4bit(uint8_t data) {
	// Xóa tất cả chân data trước khi ghi
	D4_PORT &= ~(1 << D4_PIN);
	D5_PORT &= ~(1 << D5_PIN);
	D6_PORT &= ~(1 << D6_PIN);
	D7_PORT &= ~(1 << D7_PIN);
	
	// Gán dữ liệu vào từng chân riêng biệt
	if (data & (1 << 4)) D4_PORT |= (1 << D4_PIN);
	if (data & (1 << 5)) D5_PORT |= (1 << D5_PIN);
	if (data & (1 << 6)) D6_PORT |= (1 << D6_PIN);
	if (data & (1 << 7)) D7_PORT |= (1 << D7_PIN);
	
	lcd_enable_pulse();
}

// Gửi 1 byte (8 bit) ở chế độ 4-bit
static void lcd_send_byte(uint8_t data, uint8_t rs) {
	// Thiết lập RS
	if (rs)
	LCD_RS_PORT |= (1 << RS);
	else
	LCD_RS_PORT &= ~(1 << RS);
	
	// Luôn ghi (RW = 0)
	LCD_RW_PORT &= ~(1 << RW);
	
	// Gửi 4 bit cao
	lcd_send4bit(data & 0xF0);
	// Gửi 4 bit thấp
	lcd_send4bit((data << 4) & 0xF0);
}

// === HÀM CÔNG CỘNG ===

void lcd_command(unsigned char cmnd) {
	lcd_send_byte(cmnd, 0);
	
	if (cmnd == 0x01 || cmnd == 0x02)
	_delay_ms(2);
	else
	_delay_us(50);
}

void lcd_char(unsigned char data) {
	lcd_send_byte(data, 1);
	_delay_us(50);
}

void lcd_init(void) {
	// 1. Cấu hình hướng chân (Output)
	LCD_RS_DDR |= (1 << RS);
	LCD_RW_DDR |= (1 << RW);
	LCD_EN_DDR |= (1 << EN);
	
	D4_DDR |= (1 << D4_PIN);
	D5_DDR |= (1 << D5_PIN);
	D6_DDR |= (1 << D6_PIN);
	D7_DDR |= (1 << D7_PIN);
	
	// 2. Chờ nguồn LCD ổn định
	_delay_ms(50);
	
	// 3. Đặt trạng thái ban đầu
	LCD_RS_PORT &= ~(1 << RS);
	LCD_RW_PORT &= ~(1 << RW);
	LCD_EN_PORT &= ~(1 << EN);
	
	// 4. Khởi tạo chế độ 4-bit
	lcd_send4bit(0x30);
	_delay_ms(5);
	lcd_send4bit(0x30);
	_delay_us(150);
	lcd_send4bit(0x30);
	_delay_us(150);
	
	lcd_send4bit(0x20);
	_delay_us(150);
	
	// 5. Cấu hình LCD
	lcd_command(0x28);  // 4-bit, 2 dòng, 5x8
	lcd_command(0x0C);  // Bật hiển thị, tắt con trỏ
	lcd_command(0x06);  // Tăng con trỏ
	lcd_command(0x01);  // Xóa màn hình
	_delay_ms(2);
}

void lcd_gotoxy(unsigned char x, unsigned char y) {
	unsigned char address = (y == 0) ? (0x80 + x) : (0xC0 + x);
	lcd_command(address);
}

void lcd_string(const char *str) {
	while (*str) lcd_char(*str++);
}

void lcd_clear(void) {
	lcd_command(0x01);
	_delay_ms(2);
}

void lcd_print2(uint8_t v) {
	lcd_char('0' + (v / 10));
	lcd_char('0' + (v % 10));
}

void lcd_cursor_on(void) {
	lcd_command(0x0F);
}

void lcd_cursor_off(void) {
	lcd_command(0x0C);
}

void lcd_float(float num, uint8_t digits) {
	char buffer[16];
	int32_t int_part;
	uint32_t frac_part;
	
	if (digits > 6) digits = 6;
	
	if (num < 0) {
		lcd_char('-');
		num = -num;
	}
	
	int_part = (int32_t)num;
	float remainder = num - int_part;
	frac_part = (uint32_t)(remainder * pow(10, digits) + 0.5);
	
	itoa(int_part, buffer, 10);
	lcd_string(buffer);
	
	if (digits == 0) return;
	
	lcd_char('.');
	
	char frac_buff[10];
	itoa(frac_part, frac_buff, 10);
	
	uint8_t len = 0;
	while (frac_buff[len] != '\0') len++;
	
	while (len < digits) {
		lcd_char('0');
		len++;
	}
	
	lcd_string(frac_buff);
}
