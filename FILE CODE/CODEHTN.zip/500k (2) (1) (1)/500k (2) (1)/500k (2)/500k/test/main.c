#define F_CPU 8000000UL

#include <avr/io.h>
#include <util/delay.h>
#include <stdlib.h>

#include "lcd.h"
#include "i2c.h"
#include "ds1307.h"
#include "hx711.h"
#include "keypad.h"
#include "servobuzzer.h"

// ================= BI?N =================
int32_t TARE_OFFSET = 0;

uint8_t alarm1_h = 7,  alarm1_m = 0, alarm1_s = 0;
uint8_t alarm2_h = 17, alarm2_m = 0, alarm2_s = 0;

// ================= DISPLAY SET TIME =================
void display_set_time_screen(uint8_t alarm_num, uint8_t h, uint8_t m, uint8_t s, uint8_t cursor_pos) {
	uint8_t lcd_map[] = {0, 1, 3, 4, 6, 7};

	lcd_gotoxy(0, 0);
	if (alarm_num == 1) lcd_string("SET TIME 1:");
	else                lcd_string("SET TIME 2:");

	lcd_gotoxy(0, 1);
	lcd_print2(h); lcd_char(':');
	lcd_print2(m); lcd_char(':');
	lcd_print2(s);

	lcd_gotoxy(lcd_map[cursor_pos], 1);
}

// ================= SET ALARM =================
void set_alarm_mode(uint8_t alarm_num) {
	uint8_t h, m, s;
	uint8_t pos = 0;
	char key;

	if (alarm_num == 1) { h = alarm1_h; m = alarm1_m; s = alarm1_s; }
	else                { h = alarm2_h; m = alarm2_m; s = alarm2_s; }

	lcd_clear();
	lcd_cursor_on();

	display_set_time_screen(alarm_num, h, m, s, pos);

	while(1) {
		key = read_keypad();

		if (key) {
			if (key == 'L' && pos > 0) pos--;
			else if (key == 'R' && pos < 5) pos++;

			else if (key == 'D') {
				if (alarm_num == 1) {
					alarm1_h = h; alarm1_m = m; alarm1_s = s;
					} else {
					alarm2_h = h; alarm2_m = m; alarm2_s = s;
				}
				break;
			}

			else if (key >= '0' && key <= '9') {
				uint8_t val = key - '0';

				switch(pos) {
					case 0: h = (h % 10) + val * 10; break;
					case 1: h = (h / 10) * 10 + val; break;
					case 2: m = (m % 10) + val * 10; break;
					case 3: m = (m / 10) * 10 + val; break;
					case 4: s = (s % 10) + val * 10; break;
					case 5: s = (s / 10) * 10 + val; break;
				}

				if (h > 23) h = 23;
				if (m > 59) m = 59;
				if (s > 59) s = 59;

				if (pos < 5) pos++;
			}

			display_set_time_screen(alarm_num, h, m, s, pos);
			_delay_ms(200);
		}
	}

	lcd_cursor_off();
	lcd_clear();
	lcd_string("SAVED!");
	_delay_ms(1000);
	lcd_clear();
}

// ================= MAIN =================
int main(void)
{
	uint8_t hour, min, sec;
	uint8_t old_sec = 0xFF;

	float weight_gram = 0;
	int32_t raw, net;

	char key;

	uint8_t alarm_triggered = 0;
	uint8_t buzzer_flag = 0;

	// INIT
	lcd_init();
	I2C_Init();
	hx711_init();
	keypad_init();
	system_init();

	lcd_clear();
	lcd_string("Khoi dong...");
	TARE_OFFSET = hx711_get_average(10);
	_delay_ms(500);
	lcd_clear();

	// ? COMMENT l?i ?? tr�nh reset gi?
	RTC_SetTime(14,34,0);

	while (1)
	{
		RTC_ReadTime(&hour, &min, &sec);

		// CHECK RTC L?I
		if (hour > 23 || min > 59 || sec > 59) {
			hour = 0; min = 0; sec = 0;
		}

		// HX711
		raw = hx711_get_average(5);
		net = raw - TARE_OFFSET;
		weight_gram = (float)net / SCALE_FACTOR;
		if (weight_gram < 0) weight_gram = 0;

		// KEYPAD
		key = read_keypad();

		if (key == 'A') set_alarm_mode(1);
		else if (key == 'B') set_alarm_mode(2);
		else if (key == 'C') {
			lcd_clear();
			lcd_string("Feeding...");
			feeder_dispense();
			lcd_clear();
		}

		// ===== CH?NG TRIGGER NHI?U L?N =====
		if (sec != old_sec) {
			old_sec = sec;
			alarm_triggered = 0;

			if (hour == alarm1_h && min == alarm1_m && sec == alarm1_s && !alarm_triggered) {
				lcd_clear();
				lcd_string("FEED 1");
				feeder_dispense();
				alarm_triggered = 1;
			}

			else if (hour == alarm2_h && min == alarm2_m && sec == alarm2_s && !alarm_triggered) {
				lcd_clear();
				lcd_string("FEED 2");
				feeder_dispense();
				alarm_triggered = 1;
			}

			// UPDATE LCD m?i gi�y
			lcd_gotoxy(0, 0);
			lcd_print2(hour); lcd_char(':');
			lcd_print2(min);  lcd_char(':');
			lcd_print2(sec);

			lcd_gotoxy(0, 1);
			lcd_string("Mass:");
			lcd_float(weight_gram, 1);
			lcd_string("g   ");
		}

		// ===== BUZZER CH?NG SPAM =====
		if (weight_gram <= 20.0f) {
			if (!buzzer_flag) {
				buzzer_alert(1, 100, 0);
				buzzer_flag = 1;
			}
			} else {
			buzzer_flag = 0;
		}

		_delay_ms(100);
	}
}