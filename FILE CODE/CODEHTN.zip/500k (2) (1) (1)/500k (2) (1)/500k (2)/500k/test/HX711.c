#include "hx711.h"
#include <avr/io.h>
#include <util/delay.h>
#include <avr/interrupt.h> // C?n cho h�m cli() v� sei()

/**
 * @brief Kh?i t?o c�c ch�n I/O cho HX711
 * - SCK: Output (M?c th?p)
 * - DOUT: Input
 */
void hx711_init(void) {
    // C?u h?nh ch�n SCK l� Output
    HX711_SCK_DDR |= (1 << HX711_SCK_PIN);
    
    // �?t m?c th?p cho SCK ban �?u
    HX711_SCK_PORT &= ~(1 << HX711_SCK_PIN);
    
    // C?u h?nh ch�n DOUT l� Input
    HX711_DOUT_DDR &= ~(1 << HX711_DOUT_BIT);
    
    // (T�y ch?n) B?t �i?n tr? k�o l�n cho DOUT n?u c?n
    // HX711_DOUT_PORT |= (1 << HX711_DOUT_BIT); 
}

/**
 * @brief �?c gi� tr? th� 24-bit t? HX711
 * @return Gi� tr? s? nguy�n 32-bit c� d?u
 */
int32_t hx711_read_raw(void) {
    // 1. Ch? cho ch�n DOUT xu?ng m?c th?p (Chip s?n s�ng)
    // N?u DOUT �ang cao ngh?a l� chip �ang b?n chuy?n �?i
    while (HX711_DOUT_PORT & (1 << HX711_DOUT_BIT));

    uint32_t count = 0;
    uint8_t i;

    // T?t ng?t to�n c?c �? �?m b?o th?i gian t?o xung clock ch�nh x�c
    cli();

    // 2. �?c 24 bit d? li?u (MSB tr�?c)
    for (i = 0; i < 24; i++) {
        // T?o xung Clock l�n m?c CAO
        HX711_SCK_PORT |= (1 << HX711_SCK_PIN);
        _delay_us(1); // Gi? m?c cao 1us
        
        // D?ch gi� tr? c? sang tr�i 1 bit �? ��n bit m?i
        count = count << 1;
        
        // H? xung Clock xu?ng m?c TH?P
        HX711_SCK_PORT &= ~(1 << HX711_SCK_PIN);
        _delay_us(1); // Gi? m?c th?p 1us (�? th?i gian �? chip �?y d? li?u ra)
        
        // �?c bit t? ch�n DOUT
        if (HX711_DOUT_PORT & (1 << HX711_DOUT_BIT)) {
            count++; // N?u ch�n DOUT l� 1, c?ng th�m 1 v�o bit cu?i
        }
    }

    // 3. G?i xung Clock th? 25, 26, 27 �? c?u h?nh Gain cho l?n �?c TI?P THEO
    // - 25 xung: K�nh A, Gain 128 (M?c �?nh)
    // - 26 xung: K�nh B, Gain 32
    // - 27 xung: K�nh A, Gain 64
    
    // ? ��y ta d�ng 1 xung th�m (t?ng 25) -> Gain 128
    HX711_SCK_PORT |= (1 << HX711_SCK_PIN);
    _delay_us(1);
    HX711_SCK_PORT &= ~(1 << HX711_SCK_PIN);
    _delay_us(1);
    
    // B?t l?i ng?t
    sei();

    // 4. X? l? s? �m (Sign Extension)
    // Gi� tr? t? HX711 l� s? c� d?u 24-bit (b� 2).
    // N?u bit th? 23 (bit d?u) l� 1, ngh?a l� s? �m.
    // Ta c?n m? r?ng d?u ra 32-bit �? bi?n int32_t hi?u ��ng.
    if (count & 0x00800000) {
        count |= 0xFF000000;
    }

    return (int32_t)count;
}

/**
 * @brief �?c trung b?nh nhi?u l?n �? l?c nhi?u
 * @param times S? l?n �?c
 * @return Gi� tr? trung b?nh
 */
int32_t hx711_get_average(uint8_t times) {
    int64_t sum = 0; // D�ng 64-bit �? tr�nh tr�n s? khi c?ng d?n
    
    // �?m b?o �?c �t nh?t 1 l?n
    if (times < 1) times = 1;

    for (uint8_t i = 0; i < times; i++) {
        sum += hx711_read_raw();
        // Kh�ng c?n delay gi?a c�c l?n �?c v? h�m read_raw �? c� v?ng l?p ch?
    }
    
    return (int32_t)(sum / times);}